@extends('layouts.dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <h1 class="h1">Dit is een test</h1>
            </div>
        </div>
    </div>
</div>
@endsection
