<section class="faq">
    <div class="container">
        <h2 class="h2 is-secondary">Veel gestelde vragen</h2>
        <div class="faq_wrapper">
            <div class="faq_question flex-container">
                <span class="h4">Mag een opdrachtgever mij vragen of ik gevaccineerd ben?</span>
                <i class="fa fa-plus"></i>
            </div>
            <div class="faq_answer">
                <span>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud ex</p>
                </span>
            </div>
        </div>
        <div class="faq_wrapper">
            <div class="faq_question flex-container">
                <span class="h4">Mag een opdrachtgever mij vragen of ik gevaccineerd ben?</span>
                <i class="fa fa-plus"></i>
            </div>
            <div class="faq_answer">
                <span>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud ex</p>
                </span>
            </div>
        </div>
        <div class="faq_wrapper">
            <div class="faq_question flex-container">
                <span class="h4">Mag een opdrachtgever mij vragen of ik gevaccineerd ben?</span>
                <i class="fa fa-plus"></i>
            </div>
            <div class="faq_answer">
                <span>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud ex</p>
                </span>
            </div>
        </div>
    </div>
</section>
