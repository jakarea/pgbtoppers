
<footer>
    <section class="footer_upper">
        <div class="container flex-container">
            <div class="col">
                <h4 class="h4">Contactgegevens</h4>
                <ul>
                    <li>
                        <a href="mailto:">info@pgbtoppers.nl</a>
                    </li>
                    <li>
                        <a href="mailto:">support@pgbtoppers.nl</a>
                    </li>
                </ul>
                <ul>
                    <li>
                        <a href="tel">+31 020 12345678</a>
                    </li>
                </ul>
            </div>
            <div class="col">
                <h4 class="h4">CONTACTGEGEVENS</h4>
                <ul>
                    <li>Keizergracht 520 H1017EK</li>
                    <li>Amsterdam</li>
                </ul>
                <ul>
                    <li>
                        KVK: 84497459
                    </li>
                </ul>
            </div>
            <div class="col">
                <h4 class="h4">Algemeen</h4>
                <ul>
                    <li>
                        <a href="#">Algemeene voorwaarden</a>
                    </li>
                    <li>
                        <a href="#">Privecy policy </a>
                    </li>
                </ul> 
                <ul class="flex-container socials">

                    <li>
                        <i class="fa fa-facebook"></i>
                    </li>
                    <li>
                        <i class="fa fa-instagram"></i>
                    </li>
                </ul>
            </div> 
        </div>
    </section>
    <section class="footer_end">
        <div class="container">
            <div>
                <span>Copyrigh 2022 &copy; PGBTOPPERS</span>
            </div>
        </div>
    </section>
</footer>
@include('cookie-consent::index')
