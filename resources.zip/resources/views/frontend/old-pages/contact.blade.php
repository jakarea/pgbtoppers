@extends('layouts.default', ['body_class' => 'frontend-contact-page'])
@section('content')

<section class="contact">
    <div class="container">
        <h1 class="h1">Contact opnemen</h1>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id mattis nibh. Vestibulum quis nibh vel nibh facilisis finibus. Nulla malesuada dignissim eros ac tristique. Suspendisse aliquam massa libero, tincidunt vulputate urna volutpat eleifend. Donec bibendum nibh ac convallis blandit. Mauris non orci in purus sodales ullamcorper mollis a orci. Ut cursus vel quam quis vehicula.
        </p>
    </div>
</section>

@include('partials.frontend.faq')

@endsection
